var x int
var y int = 5
var z float32 = 2.3
