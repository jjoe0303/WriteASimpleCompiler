var x int = 10

// print out variable (don't need to consider the expression)
print(x)

// print out the string constant
print("Hello World")
println("Hello World")

// print need to consider the arithmetic operation
print(1 + 2)
println(1 * x + 5)
