/*
 * We expect see the result of relational operator when match the grammar.
 * If match the grammar "2 > 1", you should print out the "ture".
 * If match the grammar "1 > 2", you should print out the "false".
 */
var x int = 1

x > 1
x >= 1
x < 1
x <= 1
x == 1
x != 1
