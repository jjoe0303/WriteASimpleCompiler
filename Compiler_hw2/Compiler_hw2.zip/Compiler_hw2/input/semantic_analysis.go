var a int = 0
var b int = 1

/* undefined variable */
c = 10

/* divide by 0 */
b = 5 / a

/* redefined variable */
var a int = b + 1