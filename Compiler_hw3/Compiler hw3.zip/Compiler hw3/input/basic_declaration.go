var x int
var y int = 5
var z float32 = 2.3

/*
 * The declaration don't need to consider the following situation
 */
var a int = 5 + 1
var b int = 5 + 1.5
