var x int = 10

if (x < 10) {
    x++
} else if(x == 10) {
    x--
} else if(x == 9) {
    x = 20
} else {
    x = 0
}
