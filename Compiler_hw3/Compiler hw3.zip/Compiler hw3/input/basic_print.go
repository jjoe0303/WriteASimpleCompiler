var x int = 10

// print out variable (don't need to consider the expression)
print(x)

// print out arithmetic operation
println(x + 10 % 5)

// print out the string constant
println("Hello World")
print("Hello World")
